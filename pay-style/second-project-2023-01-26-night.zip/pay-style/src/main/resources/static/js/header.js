$(document).ready(function(){
  $(".carousel").carousel({
     interval: 6000
  });
});