package com.payStyle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayStyleApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayStyleApplication.class, args);
	}

}
