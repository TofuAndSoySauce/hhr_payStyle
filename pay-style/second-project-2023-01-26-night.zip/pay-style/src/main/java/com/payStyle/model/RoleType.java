package com.payStyle.model;

public enum RoleType {
USER,ADMIN
}
